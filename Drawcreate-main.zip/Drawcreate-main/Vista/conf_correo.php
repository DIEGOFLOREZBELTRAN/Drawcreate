


<!-- End of Sidebar -->

<?php

        require_once 'menu.php';

?>
   
<?php

        require_once 'encabezado.php';

?>

<div class="container-fluid mb-5">

         <h1 class="mb-4 text-gray-800"><b>Configuración de correo</b></h1>

        <div class="row">
                <div class="col-12 col-lg-4 mb-3">
                        <div class="list-group" id="list-tab" role="tablist">
                                <a class="list-group-item list-group-item-action active" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">Perfil</a>
                                <a class="list-group-item list-group-item-action" id="list-security-list" data-toggle="list" href="#list-security" role="tab" aria-controls="security">Seguridad</a>
                                <a class="list-group-item list-group-item-action" id="list-mywork-list" data-toggle="list" href="#list-mywork" role="tab" aria-controls="mywork">Mi trabajo</a>
                        </div>
                </div>
                
                <div class="col-12 col-lg-8">
                </div>

        </div>
                    
</div>
<?php
    require_once 'pie.php'
?>

<script src="../Vista/JS/micuenta.js"></script>

</body>
 
</html>