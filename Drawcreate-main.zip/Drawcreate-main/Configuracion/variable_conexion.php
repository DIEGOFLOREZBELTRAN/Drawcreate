<?php

    //Se define el seridor
    DEFINE('SERVIDOR','localhost');

    //Se define el nombre de la base de datos
    DEFINE('NOMBRE_BD','DRAWCREATE');

    //Se define el usuario de la base de datos
    DEFINE('USUARIO_BD','postgres');

    //Se define la contraseña
    DEFINE('CLAVE_BD','root');

    //Se define el motor de base de datos
    DEFINE('MOTOR_BD','pgsql');



